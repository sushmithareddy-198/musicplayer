import { useContext, useEffect, useState } from 'react';
import Card from './Card';
import CreatePlaylist from './CreatePlaylist';
import { initializePlaylist } from '../initialize';
import Navbar from './Navbar';
import { MusicContext } from '../Context';
import "./Home.css";

function Home() {
  const [keyword, setKeyword] = useState('');
  const [message, setMessage] = useState('');
  const [tracks, setTracks] = useState([]);
  const [token, setToken] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);

  const { isLoading, setIsLoading, setLikedMusic, setPinnedMusic, resultOffset, setResultOffset } = useContext(MusicContext);

  const fetchMusicData = async (query = '', offset = 0) => {
    if (!token) {
      console.error('No token available');
      return;
    }

    setTracks([]);
    setMessage('');
    window.scrollTo(0, 0);
    setIsLoading(true);

    try {
      const searchQuery = query || keyword;
      const response = await fetch(
        `https://api.spotify.com/v1/search?q=${searchQuery}&type=track&offset=${offset}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to fetch music data: ${response.statusText}`);
      }

      const jsonData = await response.json();
      setTracks(jsonData.tracks.items.slice(0, 10));
    } catch (error) {
      setMessage('We couldn’t retrieve the music data. Please try again.');
      console.error('Error fetching music data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      setResultOffset(0); // Reset to first page on new search
      fetchMusicData(keyword, 0); // Fetch from the first page
    }
  };

  const handleSearchClick = () => {
    setResultOffset(0); // Reset to first page on new search
    fetchMusicData(keyword, 0); // Fetch from the first page
  };

  useEffect(() => {
    initializePlaylist();

    const fetchToken = async () => {
      try {
        setIsLoading(true);

        const response = await fetch('https://accounts.spotify.com/api/token', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: 'grant_type=client_credentials&client_id=b5945e8739bc4a6a9c2d4ac86d2199f8&client_secret=261086a815d044d98e02ef9058dd48ab',
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch token: ${response.statusText}`);
        }

        const jsonData = await response.json();
        setToken(jsonData.access_token);

        fetchMusicData('genre:indian');
      } catch (error) {
        setMessage('We couldn’t retrieve the token. Please try again.');
        console.error('Error fetching token:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchToken();
    setLikedMusic(JSON.parse(localStorage.getItem('likedMusic')) || []);
    setPinnedMusic(JSON.parse(localStorage.getItem('pinnedMusic')) || []);
  }, [setIsLoading, setLikedMusic, setPinnedMusic]);

  useEffect(() => {
    if (token && !hasSearched) {
      fetchMusicData('genre:indian');
      setHasSearched(true);
    }
  }, [token, hasSearched]);

  const playSong = (track) => {
    console.log(`Playing song: ${track.name}`);
  };

  return (
    <>
      <Navbar
        keyword={keyword}
        setKeyword={setKeyword}
        handleKeyPress={handleKeyPress}
        fetchMusicData={handleSearchClick} 
      />

      <div className="container">
        <div className={`row ${isLoading ? '' : 'd-none'}`}>
          <div className="col-12 py-5 text-center">
            <div
              className="spinner-border"
              style={{ width: '3rem', height: '3rem' }}
              role="status"
            >
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        </div>
        <div className={`row ${message ? '' : 'd-none'}`}>
          <div className="col-12 py-2 text-center">
            <h4 className="text-center text-danger">{message}</h4>
          </div>
        </div>
        <div className="row">
          {tracks.length > 0 ? (
            tracks.map((element) => (
              <Card key={element.id} element={element}>
                <button onClick={() => playSong(element)} className="btn btn-primary mt-2">Play</button>
              </Card>
            ))
          ) : (
            <div className="col-12 text-center">
              <p>No tracks available. Please perform a search.</p>
            </div>
          )}
        </div>
        {tracks.length > 0 && (
          <div className="row">
            <div className="col">
              <button
                onClick={() => {
                  setResultOffset((previous) => Math.max(previous - 20, 0));
                  fetchMusicData(keyword, resultOffset - 20);
                }}
                className="btn btn-outline-success w-100"
                disabled={resultOffset === 0}
              >
                Previous Page: {resultOffset / 20}
              </button>
            </div>
            <div className="col">
              <button
                onClick={() => {
                  setResultOffset((previous) => previous + 20);
                  fetchMusicData(keyword, resultOffset + 20);
                }}
                className="btn btn-outline-success w-100"
              >
                Next Page: {resultOffset / 20 + 2}
              </button>
            </div>
          </div>
        )}
        <div className="row">
          <div className="col-12 py-5 text-center">
            <h3 className="animated-text py-5 ">Please search for your favorite song</h3>
            <br />
            <img src="https://w0.peakpx.com/wallpaper/43/709/HD-wallpaper-hip-hop-hip-collage-music-hop.jpg" alt="Hip Hop Music Collage" className="img-fluid artistic-img" />
          </div>
        </div>
      </div>
      <div
        className="modal fade position-absolute"
        id="exampleModal"
        tabIndex={-1}
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <CreatePlaylist />
      </div>
    </>
  );
}

export default Home;



