import React, { useContext, useEffect, useState } from "react";
import { MusicContext } from "../Context";
import "./Card.css"; 
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";

function Card({ element }) {
  const musicContext = useContext(MusicContext);
  const likedMusic = musicContext.likedMusic;
  const setLikedMusic = musicContext.setLikedMusic;
  const pinnedMusic = musicContext.pinnedMusic;
  const setPinnedMusic = musicContext.setPinnedMusic;

  const [showModal, setShowModal] = useState(false);
  
  const handlePin = () => {
    let pinnedMusic = JSON.parse(localStorage.getItem("pinnedMusic")) || [];
    if (pinnedMusic.some((item) => item.id === element.id)) {
      const updatedPinnedMusic = pinnedMusic.filter(
        (item) => item.id !== element.id
      );
      setPinnedMusic(updatedPinnedMusic);
      localStorage.setItem("pinnedMusic", JSON.stringify(updatedPinnedMusic));
    } else {
      if (pinnedMusic.length < 4) {
        const updatedPinnedMusic = [...pinnedMusic, element];
        setPinnedMusic(updatedPinnedMusic);
        localStorage.setItem("pinnedMusic", JSON.stringify(updatedPinnedMusic));
      }
    }
  };

  const handleLike = () => {
    let likedMusic = JSON.parse(localStorage.getItem("likedMusic")) || [];
    if (likedMusic.some((item) => item.id === element.id)) {
      const updatedLikedMusic = likedMusic.filter(
        (item) => item.id !== element.id
      );
      setLikedMusic(updatedLikedMusic);
      localStorage.setItem("likedMusic", JSON.stringify(updatedLikedMusic));
    } else {
      const updatedLikedMusic = [...likedMusic, element];
      setLikedMusic(updatedLikedMusic);
      localStorage.setItem("likedMusic", JSON.stringify(updatedLikedMusic));
    }
  };

  useEffect(() => {
    const localLikedMusic = JSON.parse(localStorage.getItem("likedMusic")) || [];
    setLikedMusic(localLikedMusic);
  }, [setLikedMusic]);

  const handleShowModal = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);

  return (
    <>
      <div key={element.id} className="col-lg-3 col-md-6 py-2 d-flex align-items-stretch">
        <div className="card bg-dark text-white shadow-lg d-flex flex-column">
          <img
            src={element.album.images[0].url}
            className="card-img-top"
            alt={element.name}
          />
          <div className="card-body d-flex flex-column">
            <h5 className="card-title d-flex justify-content-between align-items-center">
              <span onClick={handleShowModal} className="song-title">
                {element.name}
              </span>
              <div className="add-options d-flex align-items-center">
                <button onClick={handlePin} className="btn btn-sm mx-1">
                  <i
                    className={`bi ${
                      pinnedMusic.some((item) => item.id === element.id)
                        ? "bi-pin-angle-fill"
                        : "bi-pin-angle"
                    } text-white`}
                  ></i>
                </button>
                <button onClick={handleLike} className="btn btn-sm">
                  <i
                    className={`bi ${
                      likedMusic.some((item) => item.id === element.id)
                        ? "bi-heart-fill text-danger"
                        : "bi-heart text-white"
                    }`}
                  ></i>
                </button>
              </div>
            </h5>
            <p className="card-text">Artist: {element.album.artists[0].name}</p>
            <p className="card-text">Release date: {element.album.release_date}</p>
            <div className="audio-controls mt-auto">
              <audio src={element.preview_url} controls className="w-100"></audio>
            </div>
          </div>
        </div>
      </div>

      <Modal show={showModal} onHide={handleCloseModal} centered className="modal-sm">
        <Modal.Header closeButton className="bg-dark text-white">
          <Modal.Title>{element.name}</Modal.Title>
        </Modal.Header>
        <Modal.Body className="bg-dark text-white">
          <img
            src={element.album.images[0].url}
            alt={element.name}
            className="img-fluid mb-3"
          />
          <div className="audio-controls">
            <audio src={element.preview_url} controls className="w-100"></audio>
          </div>
        </Modal.Body>
        <Modal.Footer className="bg-dark">
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default Card;
